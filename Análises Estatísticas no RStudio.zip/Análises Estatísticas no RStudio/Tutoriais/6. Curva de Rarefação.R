"Curva de Rarefação"
Autora: "Isadora Soares de Lima"
Data: "26/07/2021"
E-mail: "isadora.soareslm@gmail.com"


# Carregar o objeto phyloseq
load('Objeto_Phyloseq.RData')

# Instalar pacotes
install.packages("ggthemes")

# Carregar pacotes
library(ggthemes)
source('Custom_Functions.R')

# Criar a pasta na qual os arquivos finais serão salvos
dir.create("Curva_Rarefação/")


# Nesse tutorial eu vou te mostrar alguns dos comandos que você pode usar para personalizar seus gráficos com as suas
# cores de preferência
# Primeiro, você precisa criar uma paleta de cores:
rarecurve_colors <- c("red", "green4", "blue2", "yellow2") # essas serão as cores das nossas curvas
legend_background <- c("white", "white", "white", "white") # essas serão as cores de fundo da nossa legenda (nesse caso será necessário)

# Vou te mostrar, usando um único comando, como fazer dois tipos de gráfico diferentes
# Ao final, vou explicar como são esses dois gráficos 
# Iniciamos com a rarefação das amostras usando a função 'ggrare'
# O argumento 'step' vai determinar o "tamanho do passo" da sua curva. Em outras palavras, você escolhe em qual valor ficará 
# a curva das linhas (você pode rodar o comando várias vezes, trocando apenas o valor desse argumento para entender melhor)
# No argumento 'color', você vai definir quais serão agrupamentos do seu metadata que serão plotados e que darão cor às suas curvas  
# No argumento 'label', você vai definir quais serão nomes das suas curvas, de acordo com os dados/agrupamentos do seu metadata
p <- ggrare(obj_phyloseq, step = 50, color = "Estação", label = "AmostraID")
# Adicionando o tema
rc <- p + theme_few()
# Agora, vamos definir a cor de fundo da nossa legenda (esse passo é opcional se você quiser tirar/alterar essa cor de fundo) 
rc <- rc + scale_fill_manual(values=legend_background)
# Agora, vamos definir a cor de nossas curvas 
rc <- rc + scale_color_manual(values = rarecurve_colors)
# Defina o tamanho ('size') e cor ('color') dos valores dos eixos X e Y
rc <- rc + theme(axis.title.x = element_text(size=11, color="black"))                                                                           
rc <- rc + theme(axis.title.y = element_text(size=11, color="black"))
# Defina a cor ('color'), tamanho ('size'), e o formato ('face', sendo "bold" a opção em negrito) do título da legenda, 
# e, em seguida, o tamanho dos textos de legenda
rc <- rc + theme(legend.title = element_text(color = "black", size = 12, face = "bold"), legend.text = element_text(size = 9))
# Coloque o título dos eixos X e Y
rc <- rc + labs(x = "Tamanho das Amostras", y = "Riqueza de ASVs")
#rc <- rc + theme(text=element_text(family="sans")) # você pode mudar a fonte do texto presente em todo o gráfico, caso queira
rc

# Salve o gráfico em PDF, de acordo com suas definições de largura ('width') e altura ('height'), etc
ggsave("Curva_Rarefação/Gráfico_Curva_de_Rarefação.pdf", units="in", width=12, height=8, dpi=600, rc)

# Agora vou explicar o porquê você construiu dois gráficos em um
# Veja que, na linha 30, quando utilizamos a função 'ggrare', utilizamos dois argumentos que podem ter a mesma função, 
# dependendo de como você pretende construir seu gráfico, que são 'color' e 'label', que servem como legenda das curvas,
# sendo que uma legenda está dentro do gráfico e outra fora
# Vamos ver na prática:

p <- ggrare(obj_phyloseq, step = 50, color = "AmostraID", label = "AmostraID")

# Se você quiser mostrar somente a riqueza de ASVs na suas amostras, ignorando os agrupamentos de metadata, perceba que
# utilizar os dois argumentos, com os mesmos valores, é redundante. Se você escolher por remover a legenda (apagando o argumento
# 'color') e deixar apenas os nomes das amostras na frente das curvas, você vai perder as cores delas. Caso isso seja um
# problema, apague o argumento 'label', mantendo a legenda. 
# Tudo depende da sua escolha. Se quiser manter os dois utilizando informações diferentes, como mostrado nesse exemplo,
# apenas planeje bem sobre qual informação ficará em cada argumento, para deixar o seu gráfico mais compreensível possível.