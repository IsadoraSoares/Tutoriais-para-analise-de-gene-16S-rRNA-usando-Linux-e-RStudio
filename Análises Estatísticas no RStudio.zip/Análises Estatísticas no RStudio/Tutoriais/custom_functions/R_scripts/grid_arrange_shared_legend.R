grid_arrange_shared_legend <- function(..., ncol = length(list(...)), nrow = 1, position = c("bottom", "right","top","left"), plot=TRUE){
  plots <- list(...)
  position <- match.arg(position)
  g <- ggplotGrob(plots[[1]] + theme(legend.position = position))$grobs
  legend <- g[[which(sapply(g, function(x) x$name) == "guide-box")]]
  lheight <- sum(legend$height)
  lwidth <- sum(legend$width)
  gl <- lapply(plots, function(x) x + theme(legend.position="none"))
  gl <- c(gl, ncol = ncol, nrow = nrow)
  
  combined <- switch(position,
                     "top" = arrangeGrob(
                       legend,
                       do.call(arrangeGrob, gl),
                       ncol = 1,
                       heights = unit.c(lheight, unit(1, "npc") - lheight)),
                     "bottom" = arrangeGrob(
                       do.call(arrangeGrob, gl),
                       legend,
                       ncol = 1,
                       heights = unit.c(unit(1, "npc") - lheight, lheight)),
                     "left" = arrangeGrob(
                       legend,
                       do.call(arrangeGrob, gl),
                       ncol = 2,
                       widths = unit.c(lwidth, unit(1, "npc") - lwidth)),
                     "right" = arrangeGrob(
                       do.call(arrangeGrob, gl),
                       legend,
                       ncol = 2,
                       widths = unit.c(unit(1, "npc") - lwidth, lwidth))
  )
  
  if (plot) {
    grid.newpage()
    grid.draw(combined)
  }
  
  # return gtable invisibly
  invisible(combined)
}