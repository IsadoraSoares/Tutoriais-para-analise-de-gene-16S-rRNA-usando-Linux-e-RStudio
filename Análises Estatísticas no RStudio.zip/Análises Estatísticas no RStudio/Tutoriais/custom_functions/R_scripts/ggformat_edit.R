ggformat_edit <- function(physeq, taxaRank1 = "Phylum", taxaSet1 = "Proteobacteria",
                          taxaRank2 = "Family", numberOfTaxa = 9) {
  stopifnot(!is.null(sample_data(physeq, FALSE)),
            !is.null(tax_table(physeq, FALSE)))
  otutab <- otu_table(physeq)
  if ( !taxa_are_rows(otutab) ) {
    otutab = t(otutab)
  }
  otutab <- as(otutab, "matrix")
  otutab <- apply(otutab, 2, function(x) (x / sum(x))*100)
  ## Subset to OTUs belonging to taxaSet1 to fasten process
  stopifnot(all(c(taxaRank1, taxaRank2) %in% colnames(tax_table(physeq))))
  otutab <- otutab[tax_table(physeq)[ , taxaRank1] %in% taxaSet1, , drop = FALSE]
  if (nrow(otutab) == 0) {
    stop(paste("No otu belongs to", paste(taxaSet1, collapse = ","), "\n",
               "at taxonomic level", taxaRank1))
  }
  mdf <- melt(data = otutab, varnames = c("OTU", "Sample"))
  colnames(mdf)[3] <- "Abundance"
  ## mdf <- mdf[mdf$Abundance > 0, ] ## Remove absent taxa
  ## Add taxonomic information and replace NA and unclassified Unknown
  tax <- as(tax_table(physeq), "matrix")
  tax[is.na(tax)] <- "Unknown"
  tax[tax %in% c("", "unclassified", "Unclassified")] <- "Unknown"
  tax <- data.frame(OTU = rownames(tax), tax)
  mdf <- merge(mdf, tax, by.x = "OTU")
  ## Aggregate by taxaRank2
  mdf <- aggregate(as.formula(paste("Abundance ~ Sample +", taxaRank2)), data = mdf, FUN = sum)
  topTaxa <- aggregate(as.formula(paste("Abundance ~ ", taxaRank2)), data = mdf, FUN = sum)
  ## Keep only numberOfTaxa top taxa and aggregate the rest as "Other"
  topTax <- as.character(topTaxa[ order(topTaxa[ , "Abundance"], decreasing = TRUE), taxaRank2])
  topTax <- topTax[topTax != "Unknown"]
  topTax <- topTax[1:min(length(topTax), numberOfTaxa)]
  ## Change to character
  mdf[ , taxaRank2] <- as.character(mdf[ , taxaRank2])
  ii <- (mdf[ , taxaRank2] %in% c(topTax, "Unknown"))
  mdf[!ii , taxaRank2] <- "Other"
  mdf <- aggregate(as.formula(paste("Abundance ~ Sample +", taxaRank2)), data = mdf, FUN = sum)
  mdf[, taxaRank2] <- factor(mdf[, taxaRank2], levels = c(sort(topTax), "Unknown", "Other"))
  ## Add sample data.frame
  sdf <- as(sample_data(physeq), "data.frame")
  sdf$Sample <- sample_names(physeq)
  mdf <- merge(mdf, sdf, by.x = "Sample")
  ## Sort the entries by abundance to produce nice stacked bars in ggplot
  mdf <- mdf[ order(mdf[ , taxaRank2], mdf$Abundance, decreasing = TRUE), ]
  return(mdf)
}
