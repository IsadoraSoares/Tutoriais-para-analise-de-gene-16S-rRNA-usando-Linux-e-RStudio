"Diagrama de Venn"
Autora: "Isadora Soares de Lima"
Data: "01/07/2021"
E-mail: "isadora.soareslm@gmail.com"


# Carregar os pacotes
source('Custom_Functions.R')

# Carregar o objeto phyloseq
load('Objeto_Phyloseq.RData')

# Criar a pasta na qual os arquivos finais serão salvos
dir.create("Diagrama_Venn/")


# Verifique se está tudo certo com seu objeto phyloseq

head(tax_table(obj_phyloseq)) # 6 primeiras linhas da Tax Table
head(otu_table(obj_phyloseq)) # 6 primeiras linhas da Otu Table
sample_names(obj_phyloseq) # nomes das amostras 
sample_data(obj_phyloseq) # metadata
sample_variables(obj_phyloseq) # nomes das colunas do seu metadata
sample_sums(obj_phyloseq) # somatória do número de reads em cada amostra  
nsamples(obj_phyloseq) # número de amostras
ntaxa(obj_phyloseq) # número de linhas de com identidades taxonômicas



########################
### DIAGRAMA DE VENN ###
########################


### FILTRAGEM ###

# Comece separando as amostras que você quer analisar no seu Diagrama de Venn
# Essa separação vai ser feita totalmente a partir de algum parâmetro do seu metadata
# Para demonstração, vamos analisar somente as amostras que foram coletadas na primavera
amostras_filtradas <- subset_samples(obj_phyloseq,
                                     Estação == "Primavera")

# Vamos ver como ficou o metadata após a separação de amostras:
sample_data(amostras_filtradas)


# Faça um 'tax_glom' para o nivel hierárquico da Tax_Table que você desejar
# Aqui, vamos unir por gênero
physeq_filtrado <- tax_glom(amostras_filtradas,taxrank = "Genus")
# Verifique a Tax_Table e Otu_Table
head(tax_table(physeq_filtrado)) 
head(otu_table(physeq_filtrado))

# O diagrama de Venn leva em conta os nomes das linhas (rownames) da Tax_Table
# Dessa forma, adicione o nome dos gêneros como rownames da Tax_Table do objeto phyloseq que passou pelo 'tax_glom'
taxa_names(physeq_filtrado) <- tax_table(physeq_filtrado)[,6]
# Veja como ficou a Tax_Table
head(tax_table(physeq_filtrado))


# A função abaixo nomeada de 'merge_samples_mean' foi criada para calcular a média de duas ou mais amostras que possuam 
# o mesmo valor na tabela de ASVs (Otu_Table)
# Não altere esta função, apenas rode todas as linhas de código!
merge_samples_mean <- function(physeq, group){
  group_sums <- as.matrix(table(sample_data(physeq)[ ,group]))[,1]
  merged <- merge_samples(physeq, group)
  x <- as.matrix(otu_table(merged))
  if(taxa_are_rows(merged)){ x<-t(x) }
  out <- t(x/group_sums)
  out <- otu_table(out, taxa_are_rows = TRUE)
  otu_table(merged) <- out
  return(merged)
}

# Agora, coloque a função acima para funcionar
# Como separamos apenas as amostras coletadas na primavera, vamos comparar a amostra de solo e a de água, para saber 
# quantos gêneros elas possuem em comum. Dessa forma, usamos o parâmetro 'TipoAmostra' do metadata
media_amostras <- merge_samples_mean(physeq_filtrado, "TipoAmostra")
head(otu_table(media_amostras))


# A partir daqui, o diagrama começará a ser gerado

# Transfira o objeto 'media_amostras' para outro objeto phyloseq chamado 'physeq_venn'
physeq_venn <- media_amostras
# Atribua ao objeto 'x' o número de linhas do objeto 'physeq_venn'
x <- nrow(sample_data(physeq_venn))
x

# Foram montadas 4 opções de montagem do diagrama, e você vai rodar os comandos que correspondem ao valor do X acima 
# Caso o valor de X seja maior que 4, será preciso rodar a opção UPSET 

# Como o X, nesse tutorial, será igual a 2, vou explicar mais detalhadamente cada um dos comandos na opção 'X = 2', mas 
# todas os comentários feitos neste extendem-se às outras opções de valor de X


#
###
#####
######  X = 4 
#####
###
#


# Extraindo o nome das categorias que serão comparadas 
s1 <- rownames(as.data.frame(sample_data(physeq_venn)))[1]
s1
s2 <- rownames(as.data.frame(sample_data(physeq_venn)))[2]
s2
s3 <- rownames(as.data.frame(sample_data(physeq_venn)))[3]
s3
s4 <- rownames(as.data.frame(sample_data(physeq_venn)))[4]
s4

# Vamos filtrar as amostras que se relacionam à essas categorias no metadata, criando novos objetos phyloseq
cl <- subset_samples(physeq_venn, TipoAmostra==s1)
cl
bp <- subset_samples(physeq_venn, TipoAmostra==s2)
bp
f <- subset_samples(physeq_venn, TipoAmostra==s3)
f
nm <- subset_samples(physeq_venn, TipoAmostra==s4)
nm

# Separe as taxonomias que possuem abundância > 0 de cada um dos objetos criados
taxa_sums(cl)
cl.pruned <- prune_taxa(taxa_sums(cl) > 0, cl)
taxa_sums(cl.pruned)
taxa_sums(bp)
bp.pruned <- prune_taxa(taxa_sums(bp) > 0, bp)
taxa_sums(bp.pruned)
taxa_sums(f)
f.pruned <- prune_taxa(taxa_sums(f) > 0, f)
taxa_sums(f.pruned)
taxa_sums(nm)
nm.pruned <- prune_taxa(taxa_sums(nm) > 0, nm)
taxa_sums(nm.pruned)

# Antes de gerar o diagrama, extraia os genêros que sobraram em cada objeto
OTUs_cl.pruned <- rownames(otu_table(cl.pruned))
OTUs_cl.pruned
OTUs_bp.pruned <- rownames(otu_table(bp.pruned))
OTUs_bp.pruned
OTUs_f.pruned <- rownames(otu_table(f.pruned))
OTUs_f.pruned
OTUs_nm.pruned <- rownames(otu_table(nm.pruned))
OTUs_nm.pruned

# Crie o diagrama e salve

pdf("Diagrama_Venn/Diagrama_Primavera.pdf",  useDingbats = F,  width=11, height=8)
bp.f.nm.s_venn <- venn_diagram4(OTUs_cl.pruned,OTUs_bp.pruned, OTUs_f.pruned, OTUs_nm.pruned, s1,s2, s3,s4, colors= c("white","red","grey","blue"), euler=FALSE)
dev.off()

tiff("Diagrama_Venn/Diagrama_Primavera.tiff", units="in", width=11, height=8, res=300)
bp.f.nm.s_venn <- venn_diagram4(OTUs_cl.pruned,OTUs_bp.pruned, OTUs_f.pruned, OTUs_nm.pruned, s1,s2, s3,s4, colors= c("white","red","grey","blue"), euler=FALSE)
dev.off()

for (i in seq_along(bp.f.nm.s_venn)) {
  filename <- paste0("Diagrama_Venn/",names(bp.f.nm.s_venn)[i], ".csv")
  write.csv(bp.f.nm.s_venn[[i]], filename)
}



#
###
#####
######  X = 3
#####
###
#


# Extraindo o nome das categorias que serão comparadas 
s1 <- rownames(as.data.frame(sample_data(physeq_venn)))[1]
s1
s2 <- rownames(as.data.frame(sample_data(physeq_venn)))[2]
s2
s3 <- rownames(as.data.frame(sample_data(physeq_venn)))[3]
s3

# Vamos filtrar as amostras que se relacionam à essas categorias no metadata, criando novos objetos phyloseq
cl <- subset_samples(physeq_venn, TipoAmostra==s1)
cl
bp <- subset_samples(physeq_venn, TipoAmostra==s2)
bp
f <- subset_samples(physeq_venn, TipoAmostra==s3)
f

# Separe as taxonomias que possuem abundância > 0 de cada um dos objetos criados
taxa_sums(cl)
cl.pruned <- prune_taxa(taxa_sums(cl) > 0, cl)
taxa_sums(cl.pruned)
taxa_sums(bp)
bp.pruned <- prune_taxa(taxa_sums(bp) > 0, bp)
taxa_sums(bp.pruned)
taxa_sums(f)
f.pruned <- prune_taxa(taxa_sums(f) > 0, f)
taxa_sums(f.pruned)

# Antes de gerar o diagrama, extraia os genêros que sobraram em cada objeto
ASVs_cl.pruned <- rownames(otu_table(cl.pruned))
ASVs_cl.pruned
ASVs_bp.pruned <- rownames(otu_table(bp.pruned))
ASVs_bp.pruned
ASVs_f.pruned <- rownames(otu_table(f.pruned))
ASVs_f.pruned

# Crie o diagrama e salve

pdf("Diagrama_Venn/Diagrama_Primavera.pdf",  useDingbats = F,  width=11, height=8)
bp.f.nm.s_venn <- venn_diagram3(ASVs_cl.pruned, ASVs_bp.pruned, ASVs_f.pruned, s1, s2, s3, colors= c("white","red","grey"), euler=FALSE)
dev.off()

tiff("Diagrama_Venn/Diagrama_Primavera.tiff", units="in", width=11, height=8, res=300)
bp.f.nm.s_venn <- venn_diagram3(ASVs_cl.pruned, ASVs_bp.pruned, ASVs_f.pruned, s1, s2, s3,  colors= c("white","red","grey"), euler=FALSE)
dev.off()

for (i in seq_along(bp.f.nm.s_venn)) {
  filename <- paste0("Diagrama_Venn/",names(bp.f.nm.s_venn)[i], ".csv")
  write.csv(bp.f.nm.s_venn[[i]], filename)
}



#
###
#####
######  X = 2
#####
###
#


# Extraindo o nome das categorias que serão comparadas (no caso, "Água" e "Solo")
s1 <- rownames(as.data.frame(sample_data(physeq_venn)))[1]
s1
s2 <- rownames(as.data.frame(sample_data(physeq_venn)))[2]
s2

# Vamos filtrar as amostras que se relacionam à essas categorias no metadata, criando novos objetos phyloseq
cl <- subset_samples(physeq_filtrado, TipoAmostra==s1)
cl
bp <- subset_samples(physeq_filtrado, TipoAmostra==s2)
bp

# Separe as taxonomias que possuem abundância > 0 de cada um dos objetos criados
taxa_sums(cl)
cl.pruned <- prune_taxa(taxa_sums(cl) > 0, cl)
taxa_sums(cl.pruned)
taxa_sums(bp)
bp.pruned <- prune_taxa(taxa_sums(bp) > 0, bp)
taxa_sums(bp.pruned)

# Perceba que, em ambas as Otu_Tables, o número de taxonomias diminuiu quando comparado ao presente no objeto do passo anterior

# Antes de gerar o diagrama, extraia os genêros que sobraram em cada objeto
ASVs_cl.pruned <- rownames(otu_table(cl.pruned))
ASVs_cl.pruned
ASVs_bp.pruned <- rownames(otu_table(bp.pruned))
ASVs_bp.pruned

# Finalmente, crie o diagrama e salve em PDF

pdf("Diagrama_Venn/Diagrama_Primavera.pdf",  useDingbats = F,  width=11, height=8)
bp.f.nm.s_venn <- venn_diagram2(ASVs_cl.pruned, ASVs_bp.pruned, s1,s2, colors= c("white","red"), euler=FALSE) 
# os círculos do diagrama serão preenchidos pelas cores branco e vermelho (colors= c("white","red"))
dev.off()
# Se ocorrer algum erro na hora de utilizar a função 'venn_diagram2', abra o arquivo 'Custom_Functions.R' que está na pasta
# principal, rode a função que está na linha 26 do script, volte para esse script e rode os comandos acima mais uma vez

# Você também pode salvar no formato TIFF
tiff("Diagrama_Venn/Diagrama_Primavera.tiff", units="in", width=11, height=8, res=300)
bp.f.nm.s_venn <- venn_diagram2(ASVs_cl.pruned, ASVs_bp.pruned, s1,s2, colors= c("white","red"), euler=FALSE)
dev.off()

# No código a seguir, serão gerados aquivos .csv nomeados:
# 'Água' - contém todos os gêneros presentes na categoria "Água"
# 'Solo' - contém todos os gêneros presentes na categoria "Solo"
# 'Água_only' - contém os gêneros presentes na categoria "Água" que não são compartilhados com a categoria "Solo"
# 'Solo_only' - contém os gêneros presentes na categoria "Solo" que não são compartilhados com a categoria "Água"
# 'Água_Solo' - contém todos os gêneros compartilhados entre as categorias "Água" e "Solo"

for (i in seq_along(bp.f.nm.s_venn)) {
  filename <- paste0("Diagrama_Venn/",names(bp.f.nm.s_venn)[i], ".csv")
  write.csv(bp.f.nm.s_venn[[i]], filename)
}


#
###
#####
######  UPSET
#####
###
#


# Salve a sua Otu_Table e Tax_Table do objeto phyloseq 'media_amostras' unidas, como um data frame, no objeto 'export1'  
export1 <- data.frame(as(otu_table(media_amostras), "matrix"), as(tax_table(media_amostras), "matrix"))
# Em outro data frame, vamos transformar apenas os dados da Otu_Table em valores binários, onde tudo que for maior de 0
# será substituído pelo valor 1, e o que for menor ou igual a 0 será substituído/mantido como 0
# Dessa forma, o 0 significará ausência enquanto que o valor 1 significará presença
upset_obj <- replace(export1[,1:x],export1[,1:x] > 0, 1)
# No objeto nomeado como 'Id', coloque o nome das linhas do data frame 'upset_obj'
Id <- as.data.frame(rownames(upset_obj))
# Agora vamos unir o objeto 'Id' com o 'upset_obj'  
upset_obj1 <- cbind(Id, upset_obj)
# Renomeie o nomes das colunas
colnames(upset_obj1) <- c("Id", colnames(otu_table(media_amostras)))

# Crie o diagrama e salve no formato TIFF
dev.off()
result <- upset(upset_obj1, keep.order = F, nsets = 6, number.angles = 30, point.size = 3.5, line.size = 2, 
                mainbar.y.label = "AVS per shared", sets.x.label = "AVS per samples", order.by = "freq", sets.bar.color = "red",
                text.scale = c(1.3, 1.3, 1, 1, 2, 1.3))
tiff("Diagrama_Venn//Upset.tiff", units="in", width=11, height=8, res=300)
result
dev.off()
#
# Você também pode salvar em PDF
dev.off()
pdf("Diagrama_Venn//Upset.pdf",  width=11, height=8)
result
dev.off()