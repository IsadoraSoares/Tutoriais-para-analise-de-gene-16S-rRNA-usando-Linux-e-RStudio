"Filtragem, Tax Glom e Facet Wrap"
Autora: "Isadora Soares de Lima"
Data: "01/07/2021"
E-mail: "isadora.soareslm@gmail.com"

  
# Carregar o objeto phyloseq
load('Objeto_Phyloseq.RData')


# Nessa etapa, você vai aprender a separar seus dados de acordo com diferentes identidades taxonômicas, usando a função 'subset_taxa' 
# Você pode filtrar usando uma única identidade:
objeto_filtrado <- subset_taxa(obj_phyloseq, Family==" Flavobacteriaceae")
# Ou mesmo duas:
objeto_filtrado <- subset_taxa(obj_phyloseq, Family==" Flavobacteriaceae" & Genus == " Flavobacterium")

# Perceba que em ambos os comandos, as taxonomias foram colocadas sempre com um espaço antes (" Flavobacteriaceae"), 
# isso acontece porque, quando tiramos aquelas iniciais dos níveis de taxonomia ('d__' para Kingdom, 'p__' para Phylum, etc),
# estes foram substituídos por um espaço. Dessa forma, você pode testar os comandos tirando essse espaço, mas dará erro de identificação dessas identidades.

# Perceba que o objeto criado após a filtragem também é um objeto phyloseq, que armazena as mesmas informações do objeto inicial,
# como a Otu_Table, Tax_table e metadata.
class(objeto_filtrado)

#Visualizar a OTU_table e Tax_table

head(tax_table(objeto_filtrado))
head(otu_table(objeto_filtrado))

# Com esse novo objeto, você poderá fazer análises específicas com determinados níveis hierárquicos, ou pode simplesmente prosseguir com o
# objeto completo.


# Saiba mais da função 'subset_taxa' em: https://www.rdocumentation.org/packages/microbial/versions/0.0.19/topics/subset_taxa




##############
## TAX GLOM ##
##############

# Agora, vamos agrupar as taxonomias de acordo com um dos níveis hierarquicos, usando a função 'tax_glom' .
# Vamos começar agrupando por Kingdom:
obj_glom <- tax_glom(obj_phyloseq, 'Kingdom')
tax_table(obj_glom)
# Perceba que as colunas de Phylum, Class, Order, etc, possuem apenas valores 'NA'
# Isso acontece porque a função uniu todas as linhas que possuíam o mesmo Kingdom, ignorando as classificações seguintes

# O mesmo aconteceu com o número de reads: 
otu_table(obj_glom)

# Teste agora com níveis inferiores
obj_glom <- tax_glom(obj_phyloseq, 'Family')
tax_table(obj_glom)
otu_table(obj_tax_glom)
 
# Saiba mais da função 'tax_glom' em: https://www.rdocumentation.org/packages/phyloseq/versions/1.16.2/topics/tax_glom