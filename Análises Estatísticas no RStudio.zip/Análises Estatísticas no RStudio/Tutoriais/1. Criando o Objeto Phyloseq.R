"Criando o Objeto Phyloseq"
Autora: "Isadora Soares de Lima"
Data: "29/06/2021"
E-mail: "isadora.soareslm@gmail.com"

  
# Essa primeira etapa do tutorial vai te mostrar como criar o Objeto Phyloseq que será utilizado para fazer grande parte das análises futuras
# Nos exemplos, vou supor que você esteja analizando 4 amostras, mas caso você tenha mais ou menos amostras, só será necessário adaptar os comandos

# Vamos começar instalando um pacote na primeira opção e carregando os pacotes para ambas as opções
  
  
##mInstação Qiime2R   
if (!requireNamespace("devtools", quietly = TRUE)){install.packages("devtools")}
devtools::install_github("jbisanz/qiime2R")

# Carregar pacotes

library(qiime2R)
library(phyloseq)
library(gsubfn)
library(stringr)
library(data.table) 
source('Custom_Functions.R')


###############
### OPÇÃO 1 ###
###############

# A primeira opção é mais demorada, pois os dados ficarão mais organizados e ajustados, principalmente se você estiver mais de um arquivo de taxonomia e de ASVs

### TAX TABLE

dataframe <- as.data.frame(fread("taxonomy.tsv"))

# Armazene em um objeto a coluna com as Feature IDs 
taxonomy_ids <- as.data.frame(dataframe$`Feature ID`)
colnames(taxonomy_ids) <- "#ASV ID"

#Para ver como o objeto ficou
View(taxonomy_ids)

# Em outro objeto, armazene a coluna de taxonomia, mas agora separadas 
# A função str_splt_fixed vai separar a coluna de taxonomia do objeto "dataframe", onde as taxonomias estavam na mesma
# coluna, separadas por ";"
taxonomys <- as.data.frame(str_split_fixed(dataframe$Taxon, ";", 7))
colnames(taxonomys) <- c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", "Specie")

# Agora una os dois objetos
tax_table <- cbind(taxonomy_ids, taxonomys)


### OTU TABLE

otu <- as.data.frame(fread("Otu_Table.tsv"))

# Para que o nome da coluna com os IDs seja igual tanto na Tax Table quanto na Otu Table, precisamos separá-lo nesse arquivo também
otu_ids <- as.data.frame(otu$`#OTU ID`)
colnames(otu_ids) <- "#ASV ID"

# Separe as amostras também, sempre indicando o intervalo certo das colunas de amostras
otu_samples <- otu[2:5]

# Agora una os dois objetos com a função 'cbind'
# Essa função pegue uma sequência de argumentos de vetor, matriz ou quadro de dados e os combina por colunas
otu_table <- cbind(otu_ids, otu_samples)

# Saiba mais da função 'cbind' em: https://www.rdocumentation.org/packages/base/versions/3.6.2/topics/cbind


### MERGE ###

# Agora vamos unir a Tax Table com a Tax Table usando a função 'merge'
# A função 'merge' mescla uma sequência grande de quadros de dados ou tabelas de dados contendo variáveis que possuem
# IDs (ou chaves) comuns. As informações de saída mesclam informações que possuem IDs comuns ou as mantêm individuais 
# caso não possuam outros IDs comuns que possam mesclar 

tax_otu_table <- merge(otu_table, tax_table, by = "#ASV ID")

# O resultado final esperado é um dataframe com:
# - 1 coluna com as ASVs IDs
# - 3 colunas com os valores de ASVs
# - 7 colunas com as identidades taxonômicas

# Saiba mais da função 'merge' em: https://www.rdocumentation.org/packages/Hmisc/versions/4.5-0/topics/Merge



### TIRAR AS INICIAIS DOS NÍVEIS DAS TAXONOMIAS ###
# Essa etapa é opcional, tudo vai depender de como você quer apresentar seus dados
# Aqui, vamos retirar as letras que antecipam as taxonomias, usando, para isso, a função 'gsub'

tax_otu_table$Kingdom <- gsub('d__', "", tax_otu_table$Kingdom)
tax_otu_table$Phylum <- gsub('p__', "", tax_otu_table$Phylum)
tax_otu_table$Class <- gsub('c__', "", tax_otu_table$Class)
tax_otu_table$Order <- gsub('o__', "", tax_otu_table$Order)
tax_otu_table$Family <- gsub('f__', "", tax_otu_table$Family)
tax_otu_table$Genus <- gsub('g__', "", tax_otu_table$Genus)
tax_otu_table$Specie <- gsub('s__', "", tax_otu_table$Specie)


### AGREGAR AS TAXONOMIAS ###
# Agora você vai unir classificações taxonômicas que podem estar repetidas em todos nos níveis hierárquicos que quiser

tax <- tax_otu_table[6:12]
# Altere o intervalo de colunas de taxonomia caso o intervalo que o seu arquivo possui seja diferente do colocado no exemplo acima

# No código abaixo, você vai indicar as amostras cujas taxonomias você quer agregar (ou seja, você pode usar todas ou selecionar algumas amostras que te interessam mais). 
# É importante colocar os nomes exatos das suas amostras depois do símbolo cifrão ($) para que elas sejam acessadas corretamente
# Caso queira mudar os nomes das suas amostras, coloque o novo nome antes do símbolo de igual (=), pois ele será o nome da sua amostra depois desse comando
# !IMPORTANTE!: Se você quiser trocar o nome das amostras, os novos nomes precisam ser os mesmos que estão no metadata 
# Se quiser manter os mesmos nomes, é só repetir

samples_to_aggregate <- data.frame(tax,
                     Amostra_1 = tax_otu_table$Sample_1,
                     Amostra_2 = tax_otu_table$Sample_2,
                     Amostra_3 = tax_otu_table$Sample_3,
                     Amostra_4 = tax_otu_table$Sample_4)

# Vamos agregar até o nível de espécie, mas você pode subir os níveis, se quiser
# Função utilizada: 'aggregate'
# Esta função divide os dados em subconjuntos, calcula estatísticas resumidas para cada um e retorna o resultado em um formato conveniente
# Estas estatísticas são calculadas segundo uma função definida pelo usuário no argumento 'FUN', que pode ser aplicada a todos os subconjuntos de dados
aggregate <- aggregate(x = samples_to_aggregate[c("Amostra_1", 
                                                  "Amostra_2",
                                                  "Amostra_3",
                                                  "Amostra_4")],
                       by = samples_to_aggregate[c("Kingdom", "Phylum", "Class", "Order", "Family", "Genus", 'Specie')],
                       FUN = function(market.values){
                         sum(pmax(market.values, 0))
                       })


# Saiba mais da função 'aggregate' em: https://www.rdocumentation.org/packages/stats/versions/3.6.2/topics/aggregate



### CRIANDO O OBJETO PHYLOSEQ ###

# O objeto 'MySampleNames' vai armazenar os nomes das colunas de amostras
# Então, coloque entre as chaves o intervalo de colunas das amostras
MySampleNames <- colnames(aggregate[8:11])

# Coloque no objeto 'MyClusterNames' o que serão os nomes das linhas
MyClusterNames <- c(1:67) # substitua o 67 pelo número da linha final do dataframe 'aggregate'


# Coloque no objeto 'Mytaxanames' os nomes das colunas de taxonomia, então, coloque entre as chaves o intervalo de colunas das taxonomias
Mytaxanames <- colnames(aggregate[1:7])

# Agora vamos montar a Tax Table 
TAXtab <- aggregate[,1:7]
colnames(TAXtab) <- Mytaxanames
row.names(TAXtab) <- MyClusterNames
View(TAXtab)

# E a Otu Table 
OTUtab <- aggregate[,8:11]
colnames(OTUtab) <- MySampleNames
row.names(OTUtab) <- MyClusterNames
View(OTUtab)

# Transformando as tabelas em matrix
TAXtab <- as.matrix(TAXtab)
OTUtab <- as.matrix(OTUtab)

# Agora salvando as duas tabelas no objeto phyloseq
obj_phyloseq <- phyloseq(otu_table(OTUtab, taxa_are_rows=TRUE), tax_table(TAXtab)) 
# Caso ocorra um erro nessa parte, verifique se os valores da OTUtab estão como dados numéricos

# Verique se os nomes das amostras estão certos
sample_names(obj_phyloseq)
# Verique se o número de amostras está certo
nsamples(obj_phyloseq)

### INCLUINDO O METADATA

metadata <- as.data.frame(fread("Metadata.tsv"))

# Com o próximo comando, você vai nomear as linhas do seu metadata 
# É preciso que esses nomes sejam os mesmos das amostras do objeto phyloseq 
# Caso o seu metadata possua uma coluna com os nomes das amostras, use o comando para nomear as linhas:
row.names(metadata) <- metadata$AmostraID

# Caso não possua essa coluna, use esse comando (sempre coloque o nome das suas amostras nos comandos):
row.names(metadata) <- c("Amostra_1", "Amostra_2", "Amostra_3", "Amostra_4")

# Atribuir o metadata para outro objeto
SAMPLEtab <- metadata

# Agora, torne o conteúdo do objeto SAMPLEtab o sample_data do objeto phyloseq 
sample_data(obj_phyloseq) <- SAMPLEtab

# Por fim, salve seu objeto phyloseq
save(obj_phyloseq, file = "Objeto_Phyloseq.RData")



###############
### OPÇÃO 2 ###
###############

#Essa segunda opção é mais rápida e nela não é possível fazer as etapas de "TIRAR AS INICIAIS DOS NÍVEIS DAS TAXONOMIAS" e "AGREGAR AS TAXONOMIAS"

# Criando obj phyloseq

obj_physeq <- qza_to_phyloseq(features="07.DadaOutput/table.qza",
                              taxonomy="09.TaxonomicAnalysis/classified_rep_seqs.qza",
                              metadata = "Metadata.tsv")

save(obj_physeq, file = "Objeto_Phyloseq.RData")


# ! DICAS !

# Caso precise criar mais de um objeto e depois queira uní-los, use a função merge_phyloseq:

objs_unidos <- merge_phyloseq(physeq_1, physeq_2) 
save(objs_unidos, file = "Objeto_Phyloseq_Unido.RData")