"Diversidade Alfa"
Autora: "Isadora Soares de Lima"
Data: "01/07/2021"
E-mail: "isadora.soareslm@gmail.com"


# Carregar o objeto phyloseq
load('Objeto_Phyloseq.RData')

# Criar a pasta na qual os arquivos finais serão salvos
dir.create("Diversidade_Alfa/")

# Verifique se está tudo certo com seu objeto phyloseq

head(tax_table(obj_phyloseq)) # 6 primeiras linhas da Tax Table
head(otu_table(obj_phyloseq)) # 6 primeiras linhas da Otu Table
sample_names(obj_phyloseq) # nomes das amostras 
sample_data(obj_phyloseq) # metadata
sample_variables(obj_phyloseq) # nomes das colunas do seu metadata
sample_sums(obj_phyloseq) # somatória do número de reads em cada amostra  
nsamples(obj_phyloseq) # número de amostras
ntaxa(obj_phyloseq) # número de linhas de com identidades taxonômicas


############################
#### ALFA - Diversidade ####
############################

# Vamos estimar a riqueza com a função 'estimate_richness'
# No argumento 'measures', você pode alterar as medidas que foram colocar
# As medidas aceitas pelo comando são: "Observed", "Chao1", "ACE", "Shannon", "Simpson", "InvSimpson" e "Fisher"

alpha.diversity <- estimate_richness(obj_phyloseq,
                                     measures = c("Observed", "Chao1", "Shannon"))

# Veja o resultado:
View(alpha.diversity)

# O resultado esperado usando estas medidas é:
# 4 colunas com os valores de: Observed, Chao1, se.chao1, Shannon
# Cada linha corresponde à uma amostra


# Para mostrar graficamente os resultados de cada uma dessas medidas, use as funções 'rarefy_even_depth' e 'plot_richness'

# Vamos começar com a etapa de normalização
# Esta função é usada para fazer uma nova amostragem dos valores de abundância da Otu_Table do objeto phyloseq 
# Frequentemente, um dos principais objetivos desse procedimento é igualar o número total de contagens entre as 
# amostras, como uma alternativa a outros procedimentos de normalização formal 

obj <- rarefy_even_depth(obj_phyloseq)

# Agora vamos criar o gráfico com a função 'plot_richness'
# Esta função estima várias métricas de diversidade alfa usando a função 'estimate_richness' (que já está embutida no comando) 
# e retorna um objeto de plotagem ggplot. O gráfico gerado por esta função incluirá todas as amostras presentes no objeto phyloseq, 
# sendo que elas podem ser agrupados no eixo horizontal por meio do argumento específico do metadata, e coloridas de acordo com o outro argumento
# Você deve usar os dados não normalizados, pois muitas dessas estimativas são altamente dependentes do número de singletons. 
# Aqui, vamos usar os dados normalizados para exemplificação

# ! Sugiro que você abra o arquivo 'Gráfico_Alfa_Diversidade' no seu computador para acompanhar a explicação de cada parte dos comandos abaixo !

# Vamos usar os nomes das amostras para colorir e agrupá-las de acordo com a tipo de amostra definido no metadata
p <- plot_richness(obj, color = "AmostraID", x = "TipoAmostra", measures = c("Observed", "Chao1", "Shannon"))
# Os valores de riqueza serão plotados no gráfico como pontos (tamanho 2, como colocado no argumento 'size'), e o tema escolhido foi o bw
p <- p + geom_point(size=4) + theme_bw() 
# Para destacar o título de cada bloco de medidas, vamos colocar uma faixa de cor preta sobre esse título
p <- p + theme(strip.background = element_rect(fill="black"))
# Como a faixa possui cor preta, coloque no tipo negrito e a cor branca nas letras dos títulos
p <- p + theme(strip.text = element_text(colour = "white", face="bold"))
# Para deixar o gráfico e legenda centralizados, especifique as medidas de margem, em centímetros
p <- p + theme(plot.margin = unit(c(3,3,3,3), "cm")) 
# Defina o ângulo ('angle'), justificação ('hjust'), tamanho ('size'), e cor ('color') das palavras dos eixos X e Y
p <- p + theme(axis.text.x = element_text(angle = 90, hjust = 1, size=8, color="black"))                                                                           
p <- p + theme(axis.text.y = element_text(angle = 0, hjust = 1, size=8, color="black"))
# Por fim, escolha o título de cada eixo
grafico <- p + labs(x = "Ambiente de coleta", y = "Medidas de Diversidade Alfa")
grafico

# Salve o gráfico em PDF, de acordo com suas definições de largura ('width') e altura ('height'), etc
ggsave("Diversidade_Alfa/Gráfico_Alfa_Diversidade.pdf", units="in", width=12, height=8, dpi=600, grafico)

# Lembre-se que você sempre poderá mudar os parâmetros dos argumentos de cada comando de acordo com o modo que quer apresentar seus dados


# Saiba mais da função 'estimate_richness' em: https://www.rdocumentation.org/packages/phyloseq/versions/1.16.2/topics/estimate_richness
# Saiba mais da função 'rarefy_even_depth' em: https://www.rdocumentation.org/packages/phyloseq/versions/1.16.2/topics/rarefy_even_depth
# Saiba mais da função 'plot_richness' em: https://www.rdocumentation.org/packages/nodiv/versions/1.4.0/topics/plot_richness