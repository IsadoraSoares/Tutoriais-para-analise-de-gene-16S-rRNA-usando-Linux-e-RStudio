"Facet Wrap e Composition"
Autora: "Isadora Soares de Lima"
Data: "01/07/2021"
E-mail: "isadora.soareslm@gmail.com"


# Carregar os pacotes
source('Custom_Functions.R')

# Carregar o objeto phyloseq
load('Objeto_Phyloseq.RData')

# Criar a pasta na qual os arquivos finais serão salvos
dir.create("Facet_Wrap/")
dir.create("Composition/")


# Verifique se está tudo certo com seu objeto phyloseq

head(tax_table(obj_phyloseq)) # 6 primeiras linhas da Tax Table
head(otu_table(obj_phyloseq)) # 6 primeiras linhas da Otu Table
sample_names(obj_phyloseq) # nomes das amostras 
sample_data(obj_phyloseq) # metadata
sample_variables(obj_phyloseq) # nomes das colunas do seu metadata
sample_sums(obj_phyloseq) # somatória do número de reads em cada amostra  
nsamples(obj_phyloseq) # número de amostras
ntaxa(obj_phyloseq) # número de linhas de com identidades taxonômicas



################
## FACET WRAP ##
################

# Com a função 'plot_bar' unida à função 'facet_wrap', vamos comparar e expor graficamente a abundância de um nível 
# hierárquico específico, de acordo com um parâmetro do metadata
p <- plot_bar(obj_phyloseq, fill = "Genus") 
# Usando o parâmetro "Estação", as escalas livres no eixo X e os gráficos serão apresentados na mesma linha (nrow = 1)
# O argumento 'scales' designa o modo como as legendas do eixo X e Y serão apresentadas, podendo ser:
# "fixed", onde os eixos Y e X serão iguais em todos os quadros de gráficos 
# "free", onde os eixos Y e X serão individualmente adaptados aos seus dados 
# "free_x", onde os eixos X serão livres e os eixos Y serão fixos, ou seja, iguais entre si
# "free_y", onde os eixos Y serão livres e os eixos X serão fixos, ou seja, iguais entre si
p <- p + facet_wrap(~Estação, scales = "free_x", nrow = 1)
# Adicione o tema
p <- p + theme_bw()
# E a legenda dos eixos
p <- p + labs(x = "Amostras", y = "Abundância")
plot(p)

#Usando dois parâmetros: Estação e TipoAmostra
p <- plot_bar(obj_phyloseq, fill = "Genus") 
p <- p + facet_wrap(~Estação~TipoAmostra, scales = "free_x", nrow = 1) 
p <- p + theme_bw() 
p <- p + labs(x = "Amostras", y = "Abundância")
plot(p)

#Salvar
ggsave("Facet_Wrap/Facet_Wrap.pdf", units="in", width=16, height=10, dpi=600, p)

# Saiba mais da função 'plot_bar' em: https://www.rdocumentation.org/packages/phyloseq/versions/1.16.2/topics/plot_bar
# Saiba mais da função 'facet_wrap' em: https://www.rdocumentation.org/packages/ggplot2/versions/3.3.5/topics/facet_wrap



#################
## COMPOSITION ##
#################

# Se você quiser expor no seu gráfico apenas os grupos mais abundantes, então você pode usar a função 'plot_composition'
# unida à função 'facet_wrap', que será usanda para comparar dados do seu metadata

# No primeiro comando, vamos colocar o objeto phyloseq, seguido do primero nível taxonômico que você quer separar, depois
# escolha uma das identidades taxonômicas que pertencem ao nível escolhido inicialmente. No quarto argumento, escolha outro 
# nível taxonômico (que precisa ser sempre inferior ao primeiro escolhido), para filtrar ainda mais suas análises. 
# O argumento 'numberOfTaxa' vai definir quantos grupos serão mostrados no gráfico, sempre em ordem decrescente de abundância
# Por fim, o argumento 'fill' se refere ao nível taxonômico que será apresentado no gráfico (preferencialmente se usa o nível
# definido no quarto argumento)
p <- plot_composition(obj_phyloseq, "Kingdom", "Bacteria", "Phylum",
                       numberOfTaxa = 5, fill = "Phylum")
# Os argumentos do 'facet_wrap' foram explicado no tópico anterior
p <- p + facet_wrap(~TipoAmostra, scales = "free_x", nrow = 2)
p <- p + theme_bw()
p <- p + labs(x = "", y = "Abundância")
plot(p)


# Vamos tentar com outros níveis taxonômicos, um maior número de grupos sendo apresentados e outro parâmetro do metadata
p <- plot_composition(obj_phyloseq, "Order", " Pseudomonadales", "Family",
                       numberOfTaxa = 20, fill = "Family") # note que o Pseudomonadales foi colocado com um espaço na frente! 
p <- p + facet_wrap(~Temperatura, scales = "free_x", nrow = 2)
p <- p + theme_bw()
p <- p + labs(x = "", y = "Abundância")
plot(p)

#Salvar
ggsave("Composition/Composition_Family.pdf", units="in", width=16, height=10, dpi=600, p)


# Perceba que, memos tendo sido definido a apresentação de 20 grupos, somente 2 foram mostrados. Isso aconteceu porque 
# dentro da Ordem escolhida, existiam somente 2 famílias. Este tipo de situação pode ocorrer, não se trata de um erro
# no comando. 

# Saiba mais da função 'plot_composition' em: https://www.rdocumentation.org/packages/SAMtool/versions/1.2.0/topics/plot_composition
