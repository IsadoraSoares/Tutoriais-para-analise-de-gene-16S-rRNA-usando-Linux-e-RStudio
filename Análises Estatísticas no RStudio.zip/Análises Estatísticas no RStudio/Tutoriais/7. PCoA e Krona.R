"PCoA e Krona"
Autora: "Isadora Soares de Lima"
Data: "26/07/2021"
E-mail: "isadora.soareslm@gmail.com"


# Carregar o objeto phyloseq
load('Objeto_Phyloseq.RData')

# Instalar os pacotes
# Será necessário o Krona Tools antes de utilizar a função 'plot_krona', então siga os passos abaixo:
# Entre no site abaixo
https://github.com/marbl/Krona/releases
# Faço o download do arquivo .tar que estiver na primeira opção do Krona Tools mais atualizado (terá uma indicação ao lado
# escrito 'Latest release' na cor verde)
# Agora no terminal do Linux, escreva os seguintes comandos (depois de cada comando, aperte o entre para rodar):
$ cd Downloads/
$ tar -xvf KronaTools-2.8.tar  
# mude a versão do Krona Tools de acordo com o arquivo baixado por você
$ cd KronaTools-2.8/
$ sudo ./install.pl
# Após isso, você poderá rodar a função presente neste script.   

# Carregar pacotes
source('Custom_Functions.R')

# Criar a pasta na qual os arquivos finais serão salvos
dir.create("PCoA/")


############
### PCoA ###
############


# No primeiro comando, vamos utilizar a função 'ordinate' para ordenar os seus dados segundo alguns métodos específicos
# O método de ordenação escolhido (definido no argumento 'method') foi o MDS (Multidimensional Scaling), que é uma 
# técnica para representar graficamente n elementos em um espaço de dimensão menor que o original, levando-se  em  conta 
# as similaridades. Essa similaridade entre esses elementos (definida no argumento 'distance') será calculada pelo coeficiente  
# de similaridade Bray-Curtis, que é uma proporção de similaridade ou dissimilaridade na abundância das espécies

# Os métodos suportados pelo argumento 'method' são: "DCA", "CCA", "RDA", "CAP", "DPCoA", "NMDS", "MDS" e "PCoA"

ord <- ordinate(obj_phyloseq, method = "MDS", distance = "bray")
# Agora, utlizando a função 'plot_ordination', vamos apresentar graficamente os resultados da ordenação
# Assim como em alguns outros gráficos que fizemos, neste você precisará unir dois parâmetros do metadata, um será 
# responsável por representar os dados ('color'), e outro os agrupamentos ('shape')
p_pcoa <- plot_ordination(obj_phyloseq, ord, color = "AmostraID", shape = "Estação")
# Definindo o tema e tamanho dos pontos no gráfico
p_pcoa <- p_pcoa + theme_light() + geom_point(size = 4)
# COnfigurações do título
p_pcoa <- p_pcoa + theme(plot.title = element_text(hjust = 0, size = 12, colour =  "black", face= "bold"))
# Definindo o título
p_pcoa <- p_pcoa + ggtitle("Distância Bray-Curtis")
p_pcoa

# Salvando no formato PDF
ggsave("PCoA/Gráfico_PCoA.pdf", units="in", width=12, height=8, dpi=600, p_pcoa)


# Saiba mais da função 'ordinate' em: https://www.rdocumentation.org/packages/phyloseq/versions/1.16.2/topics/ordinate



#############
### Krona ###
#############

# O gráfico Krona compara identidades taxonômicas entre diferentes condições, de forma interativa
# A função 'plot_krona' é bem simples, não necessitando de muito argumentos e customizações 
# Vamos construir dois gráficos Krona, um deles comparando as taxonomias de cada amostra somente, e outro comparando as
# amostras entre cada Estação de coleta
plot_krona(obj_phyloseq, "Krona_Amostras", "AmostraID", trim = F)
plot_krona(obj_phyloseq, "Krona_Estação", "Estação", trim = F)

# Caso o R não consiga encontrar a função 'plot_krona', entre na pasta 'custom_functions', depois na pasta 'R_scripts',
# clique no script 'Krona.R' (ele abrirá no seu RStudio), selecione e rode os comandos presentes entre as linhas 210 e 269 
# Após esses passos, tente rodar os comandos acima novamente


# Não é necessário rodar um comando para salvar os gráficos, pois o salvamente é automático, podendo ser acessado na sua
# pasta de trabalho, em formato .html. 
# Caso você queira salvar como imagem, basta clicar nesse arquivo e quando ele abrir no seu navegador, clique com o botão
# direito do seu mouse sobre a tela e, em seguida, na opção 'Salvar imagem como...'


# Saiba mais da função 'plot_krona' em: https://rdrr.io/github/cpauvert/psadd/man/plot_krona.html